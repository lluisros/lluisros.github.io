
Description:
------------
  This supplementary material includes the equation sets and the detailed
  numerical results for the four benchmarks presented in the paper

	A Linear Relaxation Technique for the
	Position Analysis of Multiloop Linkages
  by
	J. M. Porta, L. Ros, and F. Thomas
	Institut de Robotica i Informatica Industrial
	CSIC-UPC
	Barcelona
	http://www.iri.upc.edu/groups/gmr

Size: 
-----
  The size of the compressed files is 1.1 MB.

Platform:
---------
  The files included in the supplementary material are plain ASCII files 
  that can be browsed with any text editor.

Environment:
------------
  The supplementary material does not need of any special environment.

Major Component Description:
----------------------------
  The supplementary material is included in one compressed file.
  Once uncompressed you will get four ASCII files with equations
  and results for the four benchmarks presented in the paper:

     6r-Wampler-Morgan.txt (30 KB)
		Equations and results for a 6R loop with 16 solutions. 

     6r-Bricard.txt (2.1 MB)
		Equations and results for an architecturally singular
		6R loop. The problem has a one-dimensional solution set
		that is bounded using 1686 boxes.

     6-6-Dietmeier.txt  (43 KB)
		Equations and results for a 6-6 parallel platform
		with 40 solutions. 

     6-6-Griffis-Duffy.txt (692 KB)
		Equations and results for a 6-6 architecturally singular 
		parallel platform. The problem has a one-dimensional 
		solution set that is bounded using 784 boxes.

Detailed Set-up Instructions:	
-----------------------------
  The only necessary step to access the supplementary material is to
  uncompress the file including the four result files described above.

Detailed Run Instructions:
--------------------------
  There is nothing to run in the provided supplementary material.

Output Description:
-------------------
  No output is generated from the supplementary material.

Contact Information:
--------------------
  For further details on the data in the supplementary material please
  contact the first author of the paper.
